<?php
define('URL', 'http://readytolaunchwebsites.com/models/S/ammaorphan.org/cw_admin/');
?>
