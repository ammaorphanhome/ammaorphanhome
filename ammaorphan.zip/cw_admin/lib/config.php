<?php
define('DB_TYPE','mysql');
define('DB_HOST','localhost');
define('DB_NAME','readytol_ammaorphan');
define('DB_USER','readytol_ammaorp');
define('DB_PASS','SP-(Vn!5#vT%');
$db = new PDO(DB_TYPE.':host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASS);
return($db);
?>