<?php 
require "lib/path.php";
header('location:'.URL.'login.php');
?>