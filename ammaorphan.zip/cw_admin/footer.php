<div class="card" style="background:grey;color:white;text-align:center;">
<!--position:fixed;bottom:0;width:100%;-->
				&copy; 2018 <?php echo TITLE;?>  All Right Reserved.
            </div>